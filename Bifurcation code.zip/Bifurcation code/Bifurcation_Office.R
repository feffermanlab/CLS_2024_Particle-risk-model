
library(deSolve)
library(parallel)
library(igraph)
library(tidyverse)


# delt is the proportionality constant
# C_x is the room capacity for each room
# N_total is the total number of individuals that we want in the building

Bld_setup_func_v2 <- function(Community_output,day, delt,N_rooms, C_x, N_total){
  Building_ICs <- Community_output[day,] #Retrieves the number of S, I, and R individuals in the community at a particular day.
  
  N_x  <- c(rep(0, N_rooms)) #initialize a vector
  for (i in 1:length(C_x)) {
    if (sum(N_x) >= N_total) break  # Stop if all individuals are distributed
    
    # Maximum we can place in this room, constrained by remaining individuals and room capacity
    max_for_room <- min(C_x[i], N_total - sum(N_x))
    
    # Randomly assign a number between 0 and max_for_room
    N_x[i] <- sample(0:max_for_room, 1)
  }
  
  # If after the first pass, there are still individuals left, distribute the remaining in a while loop
  while (sum(N_x) < N_total) {
    # Randomly select a room index
    room_index <- sample(1:length(N_x), 1)
    
    # Check if the selected room can accommodate more individuals
    if (N_x[room_index] < C_x[room_index] && sum(N_x) < N_total) {
      N_x[room_index] <- N_x[room_index] + 1
    }
    
    # Break if we've distributed all individuals or hit the building limit
    if (sum(N_x) >= N_total || sum(N_x) >= N_total) {
      break
    }
  }
  
  #Now we need to find how many S, I, and R individuals we should have in the building based on the proportionality constant solved for above
  Sb <- Community_output$S[day]*delt # number of susceptible in building
  Ib <- Community_output$I[day]*delt # number of Infectious in building
  Rb <- Community_output$R[day]*delt # number of Recovered in building
  
  # calculate the proportion of S,I, and R that should be in the building
  Sb_prop <- Sb/N_total
  Ib_prop <- Ib/N_total
  Rb_prop <- Rb/N_total
  
  
  # we start with no particles in the building
  P_x <- c(rep(0,N_rooms))
  
  return(data.frame(Sb = Sb, Ib = Ib, Rb = Rb,Sb_prop = Sb_prop,Ib_prop = Ib_prop,Rb_prop= Ib_prop ,P=P_x, N_x = N_x))
}


Create_T_Matrix <-function(adjacency_matrix_to_use, N_rooms){
  #set.seed(123145) # <- easier for debugging
  T_mov <- data.frame(matrix(runif(N_rooms^2), nrow = N_rooms)) #populates a square matrix/dataframe with random numbers between 0 and 1 for the number of rooms that our building has.
  
  T_mov <- adjacency_matrix_to_use*T_mov #restrict the movement according to our network/adjacency matrix
  T_mov_norm <- t(apply(T_mov, 1, function(x) x / sum(x))) # normalize so that there aren't more people moving than what can (rows should sum to 1)
  T_mov <-T_mov_norm
  return(T_mov)
}

flux_in_people <- function(N_rooms, Transition_matrix,State,Room_pops,Carrying_capacity,t){
  # Transition_matrix <- matrix(c(0,0.5,1,0.7,0,0,0.3,0.5,0), nrow = 3,ncol = 3)
  # State <- Office_setup$S_prop
  # Room_pops <- Office_setup$N_x
  # Carrying_capacity <- Office_C
  all_room_change <- c(seq(N_rooms))
  for(x in 1:N_rooms){ #flow in to room x from other rooms (j)
    flux_in_temp <- 0
    for(j in 1:N_rooms){
      flux_in_temp <- flux_in_temp + State[j]*Transition_matrix[j,x]*(1-(Room_pops[x]/Carrying_capacity[x]))
    }
    all_room_change[x] <- flux_in_temp
  }
  
  test <- c(M = as.vector(all_room_change))
  return(test)
}

flux_out_people <- function(N_rooms, Transition_matrix,State,Room_pops,Carrying_capacity){
  all_room_change <- c(seq(N_rooms))
  for(x in 1:N_rooms){
    flux_out_temp <- 0
    for(j in 1:N_rooms){
      flux_out_temp <- flux_out_temp + State[x]*Transition_matrix[x,j]*(1-(Room_pops[j]/Carrying_capacity[j]))
    }
    all_room_change[x] <- flux_out_temp
  }
  test <- c(M = as.vector(all_room_change))
  return(test)
}

flux_in_particles <- function(N_rooms, Transition_matrix,State){
  all_room_change <- c(seq(N_rooms))
  for(x in 1:N_rooms){
    flux_in_temp <- 0
    for(j in 1:N_rooms){
      flux_in_temp <- flux_in_temp + State[j]*Transition_matrix[j,x]
    }
    all_room_change[x] <- flux_in_temp
  }
  
  test <- c(M = as.vector(all_room_change))
  return(test)
}

flux_out_particles <- function(N_rooms, Transition_matrix,State){
  all_room_change <- c(seq(N_rooms))
  for(x in 1:N_rooms){
    flux_out_temp <- 0
    for(i in 1:N_rooms){
      flux_out_temp <- flux_out_temp + State[x]*Transition_matrix[x,i]
    }
    all_room_change[x] <- flux_out_temp
  }
  test <- c(M = as.vector(all_room_change))
  return(test)
}

#


#**Function for the whole model**

Particle_model_v3 <- function(t, x, parms,T_mov, theta_mov, adjacency_matrix_to_use,C_x,N_b,N_rooms,Ib_prop){
  # x <- Office_Init_conds
  # T_mov <- Office_T_mov
  # theta_mov <- Office_theta_mov
  # adjacency_matrix_to_use <- small_bld_3_rooms
  # C_x <- small_bld_3_rooms_C
  # N_b <- N_b
  N_rooms <- N_rooms
  ncompartment <- 2
  n_rooms <- length(x)/ncompartment
  N_x <- as.matrix(x[1:n_rooms])
  P <- as.matrix(x[(n_rooms+1):(2*n_rooms)])
  
  with(parms,{
    
    dN_x <- as.matrix((flux_in_people(N_rooms=N_rooms, Transition_matrix =T_mov, State=N_x,Room_pops = N_x,Carrying_capacity = C_x)) - flux_out_people(N_rooms=N_rooms, Transition_matrix = T_mov, State=N_x,Room_pops = N_x,Carrying_capacity = C_x))
    
    dP <- s*Ib_prop*as.matrix(N_x) - as.matrix(a*as.matrix(N_x)*as.matrix(P)*(1/(C_x*bet_bar))*(as.matrix(P)/bet_hat))-d*as.matrix(P) + as.matrix(as.matrix(flux_in_particles(N_rooms=N_rooms, theta_mov,State = P)) - as.matrix(flux_out_particles(N_rooms=N_rooms, theta_mov,State = P)))
    
    
    dt <- c(dN_x,dP)
    
    return(list(dt))})
}



#**Community model parameters**
#  #{r Community model parameters}
community_pop <- 100000 #pop size of the larger community
init_conds <- c(S = community_pop-1, I = 1, R = 0) 
print(init_conds)
parms <- data.frame(bet =0.0000035 , gam = 1/21) 
print(parms)
times <- seq(from = 1, to = 144, by = 1)
print(times)


##
#**Community modelfunction/equations**
# #{r communtiy model function}
SIR_community_model <- function(t, x, parms) {
  S <- x[1]
  I <- x[2]
  R <- x[3]
  
  with(parms, {
    dS <- -bet*S*I
    dI <- bet*S*I - gam*I
    dR <- gam*I
    
    dt <- c(dS,dI,dR)
    return(list(dt))
  })}


#**Community model output**

#  

Community_output <- data.frame(lsoda(y = init_conds, func = SIR_community_model,times = times, parms=parms))

# Community_output %>% pivot_longer(cols = !time) %>% arrange(desc(time))%>% 
#   ggplot(aes(x=time,y =value, color = name))+geom_line()+
#   scale_color_manual(name=NULL,values=c("blue","red","purple"),breaks = c("S","I","R"))+
#   theme_classic()+
#   labs(x= "Time (days)", y = "Number of individuals")+ggtitle("Community outbreak of pathogen")





#### Adjacency matrices ####

# small_bld_3_rooms <- matrix(c(c(1,1,1),
#                               c(1,1,1),
#                               c(1,1,1)),nrow = 3,ncol = 3)

# small_bld_5_rooms <- matrix(c(c(0,1,1,1,1),
#                               c(1,0,1,1,0),
#                               c(1,1,0,1,0),
#                               c(1,1,1,0,0),
#                               c(1,0,0,0,0)),nrow=5, ncol = 5)
# diag(small_bld_5_rooms) <-1

Office_adjacency_matrix <- matrix(c(c(0,rep(1,3),rep(0,8),rep(1,4),rep(0,30-16)), #column 1 - main area / Hallway
                                    c(1,0,0,1,rep(0,12),rep(1,4),rep(0,30-20)), # column 2 - Hallway
                                    c(1,0,0,1,rep(0,4),rep(1,4),rep(0,30-12)), # column 3 - Hallway
                                    c(1,1,1,0,1,0,1,1,rep(0,30-8)), #column 4 Main room
                                    c(rep(0,3),1,0,1,0,1,rep(0,17),1,rep(0, 30-26)), # # column 5 Hallway
                                    c(rep(0,4),1,0,1,rep(0,15),rep(1,5),0,1,1), # Column 6 Hallway
                                    c(rep(0,3),1,0,1,0,1,rep(0,30-8)), # Column 7 Hallway
                                    c(rep(0,3),1,1,0,1,rep(0,21-8),1,1,rep(0,30-22)), # Column 8 Hallway
                                    rep(c(0,0,1,rep(0,30-3)),4), # columns 9-12
                                    rep(c(1,rep(0,30-1)),4), # columns 13-16
                                    rep(c(0,1,rep(0,30-2)),4), # columns 17-20
                                    rep(c(rep(0,7),1,rep(0, 30-8)),2), # Columns 21 and 22
                                    rep(c(rep(0,5),1,rep(0,30-6)),3), # columns 23-25
                                    c(rep(0,4),1,1,rep(0,30-6)), # Column 26
                                    c(rep(0,5),1,rep(0,21),1,rep(0,30-28)), # column 27
                                    c(rep(0,26),1,rep(0,30-27)), # column 28
                                    c(rep(0,5),1,rep(0,30-6)), # column 29 
                                    c(rep(0,5),1,1,rep(0,30-7))# column 30
                                    
),nrow=30, ncol = 30)

diag(Office_adjacency_matrix) <- 1
Office_graph <- graph_from_adjacency_matrix(Office_adjacency_matrix, mode = "undirected")
Office_C <- c(161, #column 1 - main area / Hallway
              161, # column 2 - Hallway
              161, # column 3 - Hallway
              362, #column 4 Main room
              5, # # column 5 Hallway
              7, # Column 6 Hallway - slightly bigger hallway
              5, # Column 7 Hallway
              5, # Column 8 Hallway
              24, # Column 9 Large classroom
              7.7, # column 10 classroom
              7.7, #column 11 classroom
              1, # column 12 janitors closet
              11.8, # column 13 classroom
              3, # column 14 - bathroom
              11.8, # column 15 classroom
              3, # column 16 - bathroom
              7.7, # column 17 classroom
              1, # column 18 - closet
              7.7, # column 19 classroom
              23.75, # column 20 large classroom
              1, # column 21 dressing room
              1, # column 22 dressing room
              1, # column 23 office
              1, # column 24 office
              1, # column 25 office
              1, # column 26 office
              2, # column 27 office - large
              1, # column 28 small bathroom
              1, # column 29 office
              1 # column 30 office
)
# #Now that we have building defined by the adjacency matrix, we need to specify the conditions in the building
# #{r Building paramaters}
# 
# Max_Building_Capacity_small_bld <- sum(small_bld_3_rooms_C) 
Max_Building_Capacity_Office <- sum(Office_C) 

Prop_full <- data.frame(ten = 0.1,twenty = 0.2, thirty = 0.3, forty = 0.4, fifty= 0.5, sixty = 0.6, seventy = 0.7, eighty = 0.8, ninety = 0.9, hundred = 1.0) # how full do we want our building capacity to be

#ten percent capacity
Adj_Max_Building_Capacity_Office_ten <- round(Prop_full$ten[1]*Max_Building_Capacity_Office,0) #Adjusted capacity - number of individuals that will be in the building such that building is at 'Prop_full' capacity


delt_Office_ten<- Adj_Max_Building_Capacity_Office_ten/community_pop # proportionality constant ( what proportion of individuals from the community are in the building of interest)

max_I <-Community_output %>% filter(I == max(I))

beg_day <- 25 # estimated inflection point 
mid_day <- max_I$time
end_day <- 70 # lower than peak but still much greater than the beginning

Office_setup_ALL <- expand.grid(Occupancy = c(0.25,0.5, 0.75), Community_time = c(beg_day,mid_day), Max_bld_cap = sum(Office_C))

Office_setup_ALL <- Office_setup_ALL %>% mutate(Adj_cap = round(Occupancy*Max_bld_cap,0), delt = Adj_cap/community_pop)
Office_setup_ALL <- Office_setup_ALL %>% mutate(Name = c("Office_beg_out_low_occ","Office_beg_out_med_occ","Office_beg_out_high_occ",
                                                         "Office_mid_out_low_occ","Office_mid_out_med_occ","Office_mid_out_high_occ"))
Office_init_conds <- list(list())
for(i in 1:nrow(Office_setup_ALL)){  
  Office_init_conds_full <- Bld_setup_func_v2(
    Community_output = Community_output,
    day = Office_setup_ALL$Community_time[i],
    delt = Office_setup_ALL$delt[i], 
    N_rooms = length(Office_C), 
    C_x = Office_C, 
    N_total = Office_setup_ALL$Adj_cap[i]
  ) 
  
  # Assign to the list using the name from Office_setup_ALL$Name
  Office_init_conds[[Office_setup_ALL$Name[i]]] <- list(
    N_x = Office_init_conds_full$N_x,
    P = Office_init_conds_full$P,
    Ib_prop = Office_init_conds_full$Ib_prop
  )
}

parms <-data.frame(s=2000,a=396, d=1.81,bet_bar = 25569.9504, bet_hat =67320)

# Initialize large dataframe object to append to. Soing this instead of reading in the lage file every time. 
#But I will still write_out/append to the file so I don't lose data
equil_t_mov <- Create_T_Matrix(adjacency_matrix_to_use = Office_adjacency_matrix, N_rooms = length(Office_C))
equil_theta_mov <-Create_T_Matrix(adjacency_matrix_to_use = Office_adjacency_matrix, N_rooms = length(Office_C))
equil_adj_cap <- Office_setup_ALL$Adj_cap[1]
equil_Ib_prop <- Office_init_conds[["Office_beg_out_low_occ"]]$Ib_prop[1]
equil_Init_conds <- c(N_x = Office_init_conds[["Office_beg_out_low_occ"]]$N_x,P= Office_init_conds[["Office_beg_out_low_occ"]]$P)


Maxtime <- 24*50
test_times <- seq(from = 0, to = Maxtime, by = 1)
N_sims <- 100
Equil_Office_setup_ALL <- Office_setup_ALL %>% mutate(Equilib_time = 0)
equilib_time_data <- data.frame(iteration = seq(1:N_sims),Parm_set = NA, equilib_time = 0, check_steady = NA, check_persist = NA)

tolerance <- 1e-6
window_size <- 10 # Size of the moving window

Equilibrium_sim_func <- function(X){
  equil_t_mov <- Create_T_Matrix(adjacency_matrix_to_use = Office_adjacency_matrix, N_rooms = length(Office_C))
  equil_theta_mov <-Create_T_Matrix(adjacency_matrix_to_use = Office_adjacency_matrix, N_rooms = length(Office_C))
  #T_mov_file_name <- paste("/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Bifurcation_V2/",data_set_name,"_T_mov_matrix_",X,".text",sep = "")
  
  T_mov_file_name <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/Office/T_mov_files/",data_set_name,"_T_mov_matrix_",X,".text",sep = "")
  Theta_mov_file_name <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/Office/Theta_mov_files/",data_set_name,"_Theta_mov_matrix_",X,".text",sep = "")
  sim_file_name <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/Office/Indv_files/",data_set_name,"_Indv_out",X,".text",sep = "")
  #test <-read.table(T_mov_file_name)
  #  Theta_mov_file_name <- paste("/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Bifurcation_V2/",data_set_name,"_Theta_mov_matrix_",X,".text",sep = "")
  
  write.table(equil_t_mov,file =T_mov_file_name, sep = " ")
  write.table(equil_theta_mov,file =Theta_mov_file_name, sep = " ")
  
  equilib_out <- data.frame(lsoda(y = equil_Init_conds, func = Particle_model_v3,times = test_times,
                                  parms = parms,
                                  adjacency_matrix_to_use=Office_adjacency_matrix,
                                  theta_mov = equil_theta_mov,
                                  T_mov = equil_t_mov, 
                                  C_x= Office_C,
                                  N_b = equil_Adj_cap,
                                  N_rooms = length(Office_C),
                                  Ib_prop = equil_Ib_prop))
  
  
  check_steady <- NA
  check_perists <- NA
  sim <- X
  param_set <- basename(data_set_name)
  state_vars <- setdiff(names(equilib_out), "time")
  
  # Compute absolute changes for all state variables
  changes <- abs(diff(as.matrix(equilib_out[, state_vars])))
  
  # Sliding window approach to check for steady-state across all variables
  steady_state <- apply(changes, 2, function(var_changes) {
    sapply(seq_len(nrow(changes) - window_size + 1), function(i) {
      all(var_changes[i:(i + window_size - 1)] < tolerance)
    })
  })
  
  # Find the first time step where all state variables reach steady-state
  steady_time_index <- which(rowSums(steady_state) == length(state_vars))[1]
  
  if (!is.na(steady_time_index)) {
    steady_time <- equilib_out[steady_time_index, "time"]
    #message("Steady-state reached at time: ", steady_time)
    check_steady <- "Good"
  } else {
    # message("System did not reach steady-state within the simulation time.")
    check_steady <- "steady-state not reached"
  }
  
  # Ensure steady-state persists after steady_time
  check_perists
  if (!is.na(steady_time_index)) {
    persistent <- all(changes[seq(steady_time_index, nrow(changes)), ] < tolerance)
    if (persistent) {
      #message("Steady-state persists after the initial steady-state point.")
      check_perists <- "S.S. persists"
    } else {
      #message("Steady-state does not persist after it was initially reached.")
      check_perists <-"S.S. does NOT persists"
    }
  }else{
    check_perists <- "No S.S"
  }
  
  small_out <- equilib_out %>% mutate(sim = sim, param_set = param_set, check_steady = check_steady, check_perists = check_perists)
  
  write.table(small_out,file =sim_file_name, sep = " ",col.names = TRUE ,row.names = TRUE)
  
  return(sim_file_name)
}




for (i in 1:nrow(Office_setup_ALL)) {  
  #print(paste("iteration ", i, "of for loop"))
  # Loop through the different parameter sets
  #Large_out_list <- list()
  equil_Init_conds <- c(N_x = Office_init_conds[[Office_setup_ALL$Name[i]]]$N_x,P= Office_init_conds[[Office_setup_ALL$Name[i]]]$P)
  #print(equil_Init_conds)
  Init_cnd_df <- as.data.frame(t(equil_Init_conds))
  equil_adj_cap <- c(Office_setup_ALL$Adj_cap[i])
  #print(equil_adj_cap)
  equil_Ib_prop <- c(Office_init_conds[[Office_setup_ALL$Name[i]]]$Ib_prop[1])
  #print(equil_Ib_prop)
  #file_directory <- "/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Office_data/"
  #file_directory <- "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Office_data_smaller/"
  #file_name <- paste("/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Office_data_smaller/Test_",Office_setup_ALL$Name[i],".text",sep = "")
  data_set_name <- Office_setup_ALL$Name[i]
  #file_name <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/Office/Full_output",Office_setup_ALL$Name[i],".text",sep = "")
  #write.table(as.data.frame(c(time = 0, Init_cnd_df, sim = NA, param_set = NA, check_steady = NA, check_perists = NA)), 
  #           file = file_name, row.names = FALSE, col.names = TRUE)
  
  #test <-read.table(file_name, header = TRUE)
  #Run several iterations of the ode, store the times that it reaches equilibrium
  sim_files <- mclapply(FUN =Equilibrium_sim_func, X = 1:N_sims, mc.cores = detectCores())
  #write it out so we save the data in case it breaks
  all_data <- do.call(rbind, lapply(sim_files, read.table, header = TRUE))
  
  # Write final combined data
  final_output_file <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/Office/Full_output/", 
                             data_set_name, "_Final_Output.text", sep = "")
  write.table(all_data, file = final_output_file, sep = " ", row.names = TRUE, col.names = TRUE)
  
  
}
#test <- read.table(file =final_output_file, header = TRUE)
#print(test)
# if (!all(names(small_out) == column_names)) {
#   stop("Column names mismatch! Check your `small_out` structure.")
# }
#file_name2 <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Full_Equilib_Office_",sep = "")
#write.table(Equil_Office_setup_ALL,file =file_name2, sep = " ")
#test <-read.table(file_name, header = TRUE)

