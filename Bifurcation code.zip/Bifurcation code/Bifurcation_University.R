
library(deSolve)
library(parallel)
library(igraph)
library(tidyverse)


# delt is the proportionality constant
# C_x is the room capacity for each room
# N_total is the total number of individuals that we want in the building

Bld_setup_func_v2 <- function(Community_output,day, delt,N_rooms, C_x, N_total){
  Building_ICs <- Community_output[day,] #Retrieves the number of S, I, and R individuals in the community at a particular day.
  
  N_x  <- c(rep(0, N_rooms)) #initialize a vector
  for (i in 1:length(C_x)) {
    if (sum(N_x) >= N_total) break  # Stop if all individuals are distributed
    
    # Maximum we can place in this room, constrained by remaining individuals and room capacity
    max_for_room <- min(C_x[i], N_total - sum(N_x))
    
    # Randomly assign a number between 0 and max_for_room
    N_x[i] <- sample(0:max_for_room, 1)
  }
  
  # If after the first pass, there are still individuals left, distribute the remaining in a while loop
  while (sum(N_x) < N_total) {
    # Randomly select a room index
    room_index <- sample(1:length(N_x), 1)
    
    # Check if the selected room can accommodate more individuals
    if (N_x[room_index] < C_x[room_index] && sum(N_x) < N_total) {
      N_x[room_index] <- N_x[room_index] + 1
    }
    
    # Break if we've distributed all individuals or hit the building limit
    if (sum(N_x) >= N_total || sum(N_x) >= N_total) {
      break
    }
  }
  
  #Now we need to find how many S, I, and R individuals we should have in the building based on the proportionality constant solved for above
  Sb <- Community_output$S[day]*delt # number of susceptible in building
  Ib <- Community_output$I[day]*delt # number of Infectious in building
  Rb <- Community_output$R[day]*delt # number of Recovered in building
  
  # calculate the proportion of S,I, and R that should be in the building
  Sb_prop <- Sb/N_total
  Ib_prop <- Ib/N_total
  Rb_prop <- Rb/N_total
  
  
  # we start with no particles in the building
  P_x <- c(rep(0,N_rooms))
  
  return(data.frame(Sb = Sb, Ib = Ib, Rb = Rb,Sb_prop = Sb_prop,Ib_prop = Ib_prop,Rb_prop= Ib_prop ,P=P_x, N_x = N_x))
}


Create_T_Matrix <-function(adjacency_matrix_to_use, N_rooms){
  #set.seed(123145) # <- easier for debugging
  T_mov <- data.frame(matrix(runif(N_rooms^2), nrow = N_rooms)) #populates a square matrix/dataframe with random numbers between 0 and 1 for the number of rooms that our building has.
  
  T_mov <- adjacency_matrix_to_use*T_mov #restrict the movement according to our network/adjacency matrix
  T_mov_norm <- t(apply(T_mov, 1, function(x) x / sum(x))) # normalize so that there aren't more people moving than what can (rows should sum to 1)
  T_mov <-T_mov_norm
  return(T_mov)
}

flux_in_people <- function(N_rooms, Transition_matrix,State,Room_pops,Carrying_capacity,t){
  # Transition_matrix <- matrix(c(0,0.5,1,0.7,0,0,0.3,0.5,0), nrow = 3,ncol = 3)
  # State <- University_setup$S_prop
  # Room_pops <- University_setup$N_x
  # Carrying_capacity <- University_C
  all_room_change <- c(seq(N_rooms))
  for(x in 1:N_rooms){ #flow in to room x from other rooms (j)
    flux_in_temp <- 0
    for(j in 1:N_rooms){
      flux_in_temp <- flux_in_temp + State[j]*Transition_matrix[j,x]*(1-(Room_pops[x]/Carrying_capacity[x]))
    }
    all_room_change[x] <- flux_in_temp
  }
  
  test <- c(M = as.vector(all_room_change))
  return(test)
}

flux_out_people <- function(N_rooms, Transition_matrix,State,Room_pops,Carrying_capacity){
  all_room_change <- c(seq(N_rooms))
  for(x in 1:N_rooms){
    flux_out_temp <- 0
    for(j in 1:N_rooms){
      flux_out_temp <- flux_out_temp + State[x]*Transition_matrix[x,j]*(1-(Room_pops[j]/Carrying_capacity[j]))
    }
    all_room_change[x] <- flux_out_temp
  }
  test <- c(M = as.vector(all_room_change))
  return(test)
}

flux_in_particles <- function(N_rooms, Transition_matrix,State){
  all_room_change <- c(seq(N_rooms))
  for(x in 1:N_rooms){
    flux_in_temp <- 0
    for(j in 1:N_rooms){
      flux_in_temp <- flux_in_temp + State[j]*Transition_matrix[j,x]
    }
    all_room_change[x] <- flux_in_temp
  }
  
  test <- c(M = as.vector(all_room_change))
  return(test)
}

flux_out_particles <- function(N_rooms, Transition_matrix,State){
  all_room_change <- c(seq(N_rooms))
  for(x in 1:N_rooms){
    flux_out_temp <- 0
    for(i in 1:N_rooms){
      flux_out_temp <- flux_out_temp + State[x]*Transition_matrix[x,i]
    }
    all_room_change[x] <- flux_out_temp
  }
  test <- c(M = as.vector(all_room_change))
  return(test)
}

#


#**Function for the whole model**

Particle_model_v3 <- function(t, x, parms,T_mov, theta_mov, adjacency_matrix_to_use,C_x,N_b,N_rooms,Ib_prop){
  # x <- University_Init_conds
  # T_mov <- University_T_mov
  # theta_mov <- University_theta_mov
  # adjacency_matrix_to_use <- small_bld_3_rooms
  # C_x <- small_bld_3_rooms_C
  # N_b <- N_b
  N_rooms <- N_rooms
  ncompartment <- 2
  n_rooms <- length(x)/ncompartment
  N_x <- as.matrix(x[1:n_rooms])
  P <- as.matrix(x[(n_rooms+1):(2*n_rooms)])
  
  with(parms,{
    
    dN_x <- as.matrix((flux_in_people(N_rooms=N_rooms, Transition_matrix =T_mov, State=N_x,Room_pops = N_x,Carrying_capacity = C_x)) - flux_out_people(N_rooms=N_rooms, Transition_matrix = T_mov, State=N_x,Room_pops = N_x,Carrying_capacity = C_x))
    
    dP <- s*Ib_prop*as.matrix(N_x) - as.matrix(a*as.matrix(N_x)*as.matrix(P)*(1/(C_x*bet_bar))*(as.matrix(P)/bet_hat))-d*as.matrix(P) + as.matrix(as.matrix(flux_in_particles(N_rooms=N_rooms, theta_mov,State = P)) - as.matrix(flux_out_particles(N_rooms=N_rooms, theta_mov,State = P)))
    
    
    dt <- c(dN_x,dP)
    
    return(list(dt))})
}



#**Community model parameters**
#  #{r Community model parameters}
community_pop <- 100000 #pop size of the larger community
init_conds <- c(S = community_pop-1, I = 1, R = 0) 
print(init_conds)
parms <- data.frame(bet =0.0000035 , gam = 1/21) 
print(parms)
times <- seq(from = 1, to = 144, by = 1)
print(times)


##
#**Community modelfunction/equations**
# #{r communtiy model function}
SIR_community_model <- function(t, x, parms) {
  S <- x[1]
  I <- x[2]
  R <- x[3]
  
  with(parms, {
    dS <- -bet*S*I
    dI <- bet*S*I - gam*I
    dR <- gam*I
    
    dt <- c(dS,dI,dR)
    return(list(dt))
  })}


#**Community model output**

#  

Community_output <- data.frame(lsoda(y = init_conds, func = SIR_community_model,times = times, parms=parms))

# Community_output %>% pivot_longer(cols = !time) %>% arrange(desc(time))%>% 
#   ggplot(aes(x=time,y =value, color = name))+geom_line()+
#   scale_color_manual(name=NULL,values=c("blue","red","purple"),breaks = c("S","I","R"))+
#   theme_classic()+
#   labs(x= "Time (days)", y = "Number of individuals")+ggtitle("Community outbreak of pathogen")





#### Adjacency matrices ####

# small_bld_3_rooms <- matrix(c(c(1,1,1),
#                               c(1,1,1),
#                               c(1,1,1)),nrow = 3,ncol = 3)

# small_bld_5_rooms <- matrix(c(c(0,1,1,1,1),
#                               c(1,0,1,1,0),
#                               c(1,1,0,1,0),
#                               c(1,1,1,0,0),
#                               c(1,0,0,0,0)),nrow=5, ncol = 5)
# diag(small_bld_5_rooms) <-1


University_adjacency_matrix<- matrix(c(rep(c(rep(0,34),1,rep(0,231-35)),6),#Basement floor -rooms 1-6
                                       rep(c(rep(0,35),1,rep(0,231-36)),4), #rooms 7-10
                                       c(rep(0,35),1,0,0,1,1,rep(0,231-40)), #room 11
                                       c(rep(0,36),1,rep(0,231-37)), #room 12
                                       c(rep(0,13),1,rep(0,22),1,rep(0,231-37)), #room 13
                                       c(rep(0,12),1,0,1,0,1,rep(0,20),1, rep(0,231-38)), #room 14
                                       c(rep(0,13),1,0,1,0,1,1,rep(0,18),1,rep(0,231-38)), #room 15
                                       c(rep(0,14),1,rep(0,4),1,1, rep(0,16),1,rep(0,231-38)), #room 16
                                       c(rep(0,13),1,rep(0,231-14)), #room 17
                                       rep(c(rep(0,14),1,rep(0,231-15)),2), #rooms 18-19
                                       rep(c(rep(0,15),1,rep(0,231-16)),2), #rooms 20-21
                                       c(rep(0,39),1,rep(0,231-40)), #room 22
                                       c(rep(0,39),1,1,rep(0, 231-41)), #room 23
                                       rep(c(rep(0,40), 1, rep(0,231-41)),2), #rooms 24-25
                                       c(rep(0,26),1,rep(0,13),1,1,rep(0,231-42)), #room 26
                                       c(rep(0,25),1,rep(0,16),1,rep(0,231-43)), #room 27
                                       c(rep(0,29),1,rep(0,11),1,rep(0,231-42)), # room 28
                                       c(rep(0,30),1,rep(0,10),1,rep(0,231-42)), #room 29
                                       c(rep(0,27),1,rep(0,231-28)), #room 30
                                       c(rep(0,28),1,rep(0,231-29)), #room 31
                                       c(rep(0,41),1,rep(0,231-42)), #room 32
                                       c(rep(0,41),1,1,rep(0,231-43)), #room 33
                                       c(rep(0,42),1,rep(0,231-43)), #room 34
                                       #BASEMENT LEVEL HALLWAYS
                                       c(rep(1,6),rep(0,29),1,rep(0,7),1,rep(0,231-44)), #room 35 - (hallway)
                                       c(rep(0,6),rep(1,5),rep(0,25),1,0,1,rep(0,231-39)), #room 36 - (hallway)
                                       c(rep(0,11),1,1,rep(0,22),1,0,1,rep(0,6),1,rep(0,231-45)), #room 37 - (hallway)
                                       c(rep(0,13),rep(1,3),rep(0,20),1,0,0,1,rep(0,231-40)), #room 38 - (hallway)
                                       c(rep(0,10),1,rep(0,24),1,0,0,0,1,rep(0,231-40)), #room 39 - (hallway)
                                       c(rep(0,10),1,rep(0,10),1,1,rep(0,14),1,1,0,1,0,0,0,0,1,rep(0,231-46)), #room 40 - hallway
                                       c(rep(0,22),rep(1,4),rep(0,13),1,0,1,rep(0,231-42)), #room 41 - (hallway)
                                       c(rep(0,25),1,0,1,1,0,0,1,1,rep(0,9),1, rep(0,231-43)), #room 42 - (hallway)
                                       c(rep(0,32),1,1,rep(0,7),1,rep(0,4),1,rep(0,231-47)), #room 43 - (hallway)
                                       #STAIRS AND ELEVATORS * will fill in as I go, want to check the network of each floor
                                       c(rep(0,34),1,rep(0,188),1,rep(0,231-224)), #room 44 - (stairwell 1)
                                       c(rep(0,36),1,rep(0,14),1,rep(0,90),1,0,1,rep(0,64),1,0,1,rep(0,231-212)), #room 45 - (elevator 1)
                                       c(rep(0,39),1,rep(0,46),1,rep(0,62),1,rep(0,66),1,rep(0,231-217)), #room 46 - (elevator 2)
                                       c(rep(0,42),1,rep(0,183),1,rep(0,231-227)),  #room 47 - (stairwell 2)
                                       ################# LEVEL 1 ##
                                       rep(c(rep(0,80),1,rep(0,231-81)),2), # rooms 48 and 49
                                       c(rep(0,80),1,0,1,rep(0,231-83)), # room 50
                                       c(rep(0,80),1,rep(0,231-81)), #room 51
                                       c(rep(0,44),1,rep(0,7),1,rep(0,11),1,rep(0,15),1,1,rep(0,231-82)), # room 52
                                       c(rep(0,51),1,rep(0,231-52)), # room 53
                                       rep(c(rep(0,82),1,rep(0,231-83)),7), # rooms 54-60,
                                       c(rep(0,83),1,rep(0,231-84)), # room 61
                                       c(rep(0,66),1,rep(0,17),1,0,1,rep(0,231-87)), #room 62
                                       c(rep(0,84),1,rep(0,231-85)), # room 63
                                       c(rep(0,66),1,rep(0,17),1,rep(0,231-85)), # room 64
                                       c(rep(0,51),1,rep(0,32),1,rep(0,231-85)), # room 65
                                       c(rep(0,84),1,rep(0,231-85)), # room 66
                                       c(rep(0,61),1,0,1,rep(0,231-64)), #room 67
                                       rep(c(rep(0,86),1,rep(0,4),1,rep(0,231-92)),2), # room 68 and 69
                                       rep(c(rep(0,89),1,rep(0,231-90)),3), # room 70:72
                                       rep(c(rep(0,90),1,rep(0,231-91)),3), # room 73-75
                                       rep(c(rep(0,91),1,rep(0,231-92)),4), # room 76:79
                                       c(rep(0,85),1,0,1,0,0,1,rep(0,231-91)), # room 80
                                       c(rep(0,47),rep(1,5),rep(0,29),1,rep(0,141),1,rep(0,231-224)), # room 81 - (hallway)
                                       c(rep(0,51),1,rep(0,28),1,0,1,1,1,rep(0,231-85)), # room 82 - (Hallway)
                                       c(rep(0,49),1,0,0,0,rep(1,7),rep(0,21),1,0,1,rep(0,231-84)), # room 83 - (Hallway)
                                       c(rep(0,60),1,rep(0,20),1,1,0,1,1,1,1,1,rep(0,231-89)), # room 84 - (Hallway)
                                       c(rep(0,61),rep(1,5),rep(0,15),1,0,1,rep(0,231-84)), # room 85 - (Hallway)
                                       c(rep(0,79),1,0,0,0,1,0,0,0,1,rep(0,231-88)), # room 86 - (Hallway)
                                       c(rep(0,45),1,rep(0,15),1,rep(0,5),1,1,rep(0,14),1,rep(0,4),1,1,rep(0,231-90)), # room 87 - (Hallway)
                                       c(rep(0,79),1,rep(0,3),1,0,1,rep(0,4),1,rep(0,231-91)), # room 88 - (Hallway)
                                       c(rep(0,83),1,0,0,1,rep(0,3),1,rep(0,231-91)), # room 89 - (Hallway)
                                       c(rep(0,69),rep(1,3),rep(0,14),1, rep(0,231-87)), # room 90 - Hallway
                                       c(rep(0,72),1,1,1,rep(0,4),1, rep(0,7),1,1,0,0,1,1, rep(0,231-93)), # room 91 - (Hallway)
                                       c(rep(0,67),1,1,rep(0,6),rep(1,4),rep(0,147),1,rep(0,231-227)), # room 92 - (Hallway)
                                       ########################## STAIR ON LEVEL 1 room - 93###
                                       c(rep(0,90),1,rep(0,138),1,0), # room 93 ( Staircase)
                                       ########################## BEGIN FLOOR 2 ###
                                       rep(c(rep(0,140),1,rep(0,231-141)),3), # rooms 94:96
                                       rep(c(rep(0,141),1,rep(0,231-142)),4), # rooms 97:100
                                       rep(c(rep(0,143),1,rep(0,231-144)),4), #rooms 101: 104
                                       c(rep(0,141),1,1,rep(0,231-143)), # room 105
                                       c(rep(0,142),1,rep(0,231-143)), #room 106
                                       c(rep(0,144),1,rep(0,231-145)), # room 107
                                       c(rep(0,112),1,1,rep(0,30),1,1,1,rep(0,231-147)), # room 108
                                       c(rep(0,144),1,1,1,rep(0,231-147)), #room 109
                                       c(rep(0,144),1,1,rep(0,231-146)), # room 110
                                       c(rep(0,145),1,rep(0,231-146)), # room 111
                                       c(rep(0,146),1, rep(0,231-147)), # room 112
                                       rep(c(rep(0,107),1,rep(0,231-108)),2), # rooms 113 and 114
                                       rep(c(rep(0,147),1,rep(0,231-148)),2), # rooms 115 and 116
                                       c(rep(0,149),1,rep(0,231-150)), # room 117
                                       rep(c(rep(0,148),1,rep(0,231-149)),3), # room 118:120
                                       c(rep(0,121),1,rep(0,25),1,rep(0,6),1, rep(0,231-155)), # room 121
                                       c(rep(0,120),1,rep(0,32),1,rep(0,231-154)), # room 122
                                       rep(c(rep(0,154),1,rep(0,231-155)),3), # rooms 123:125
                                       rep(c(rep(0,152),1,rep(0,231-153)),2), # rooms 126 and 127
                                       rep(c(rep(0,153),1,rep(0,231-154)),5), # rooms 128:132
                                       rep(c(rep(0,152),1,1,rep(0,231-154)),2), # rooms 133 and 134
                                       c(rep(0,135),1,0,1,1,rep(0,11),1,rep(0,231-151)), # room 135
                                       c(rep(0,134),1,0,0,0,1,rep(0,231-139)), # room 136
                                       c(rep(0,137),1,1,rep(0,231-139)), # room 137
                                       c(rep(0,134),1,0,1,rep(0,231-137)), # room 138
                                       c(rep(0,134),1,1,1,rep(0,231-137)), # room 139
                                       c(rep(0,150),1,rep(0,231-151)), # room 140
                                       ############ start of level 2 Hallways ###
                                       c(rep(0,93),1,1,1,rep(0,45),1,rep(0,82),1,rep(0,231-225)), # room 141 - (Hallway)
                                       c(rep(0,96),rep(1,4),rep(0,4),1,rep(0,35),1,0,1,1,rep(0,231-144)), # room 142 - (Hallway)
                                       c(rep(0,44),1, rep(0,59),1,1,rep(0,35),1,0,0,1,rep(0,231-145)), # room 143 - (Hallway)
                                       c(rep(0,100),rep(1,4),rep(0,45),1,1,rep(0,231-151)), # room 144 - (Hallway)
                                       c(rep(0,44),1,rep(0,61),rep(1,4),rep(0,32),1,rep(0,231-143)), # room 145 - (Hallway)
                                       c(rep(0,107),rep(1,4),rep(0,231-111)), # room 146 - (Hallway)
                                       c(rep(0,107),1,1,0,0,1,rep(0,35),1,rep(0,231-148)), # room 147 - (Hallway)
                                       c(rep(0,114),1,1,rep(0,4),1,rep(0,25),1,0,0,1,rep(0,231-150)), # room 148
                                       c(rep(0,117), 1,1,1,rep(0,29),1,rep(0,231-150)), # room 149 - (Hallway)
                                       c(rep(0,45),1,rep(0,70),1,rep(0,26),1,rep(0,3),1,1,0,1,1,rep(0,77),1,0), # room 150 - (Hallway)
                                       c(rep(0,134),1,0,0,0,1,1,rep(0,3),1,rep(0,5),1,0,0,1,rep(0,231-153)), # room 151 - (Hallway)
                                       c(rep(0,149),1,0,0,1,rep(0,231-153)), # room 152 - (Hallway)
                                       c(rep(0,125),1,1,rep(0,5),1,1,rep(0,4),1,rep(0,11),1,1,rep(0,77),1,0),# room 153 - (Hallway)
                                       c(rep(0,121),1,rep(0,4),rep(1,8),rep(0,18),1,0,1,rep(0,72),1,rep(0,231-228)), # room 154 - (Hallway)
                                       c(rep(0,120),1,0,1,1,1,rep(0,28),1,rep(0,231-154)), # room 155 - (Hallway),
                                       ##################### BEGIN LEVEL 3 ### !!!!!!!!!!!!
                                       rep(c(rep(0,207),1,rep(0,231-208)),2), # room 156 and 157
                                       c(rep(0,207),1,1,rep(0,231-209)), # room 158
                                       rep(c(rep(0,208),1,rep(0,231-209)),4), # rooms 159-162
                                       rep(c(rep(0,210),1,rep(0,231-211)),4), # rooms 163-166
                                       c(rep(0,208),1,1,rep(0,231-210)), # room 167
                                       c(rep(0,211),1,rep(0,231-212)), # room 168
                                       c(rep(0,173),1,1,rep(0,36),1,1,1,1,rep(0,231-215)), # room 169
                                       c(rep(0,211),1,1,1,rep(0,231-214)), # room 170
                                       c(rep(0,211),1,1,rep(0,231-213)), # room 171
                                       c(rep(0,212),1,rep(0,231-213)), # room 172
                                       c(rep(0,213),1,rep(0,231-214)), # room 173
                                       rep(c(rep(0,168),1,rep(0,231-169)),2), # rooms 174 and 175
                                       rep(c(rep(0,214),1,rep(0,231-215)),2), # rooms 176 and 177
                                       c(rep(0,214),1,rep(0,6),1,1,rep(0,231-223)), # room 178
                                       c(rep(0,222),1,rep(0,231-223)), # room 179
                                       rep(c(rep(0,221),1,rep(0,231-222)),3), # rooms 180-182
                                       c(rep(0,215),1,1,rep(0,231-217)), # room 183
                                       rep(c(rep(0,215),1,rep(0,231-216)),3), # rooms 184-186
                                       c(rep(0,219),1,rep(0,231-220)), # room 187
                                       c(rep(0,219),1,1,rep(0,231-221)), # room 188
                                       rep(c(rep(0,220),1,rep(0,231-221)),4), # room 189-192
                                       c(rep(0,220),1,rep(0,231-221)), # room 193
                                       rep(c(rep(0,219),1,1,rep(0,231-221)),2), # rooms 194 and 195
                                       c(rep(0,217),1,rep(0,231-218)), # room 196
                                       c(rep(0,197),1,1,1,rep(0,17),1,rep(0,231-218)), # room 197
                                       c(rep(0,196),1,rep(0,231-197)), # room 198
                                       c(rep(0,196),1,0,0,rep(1,5),rep(0,231-204)), # room 199
                                       c(rep(0,196),1,0,1,rep(0,231-199)), # room 200
                                       rep(c(rep(0,198),1,rep(0,231-199)),4), # rooms 201-204
                                       rep(c(rep(0, 217),1,rep(0,231-218)),3), # rooms 205-207
                                       ######## LEVEL 3 HALLWAYS ###
                                       c(rep(0,43),1,rep(0,111),1,1,1,rep(0,50),1,rep(0,231-209)),# room 208 - (Hallway)
                                       c(rep(0,157),rep(1,5),rep(0,4),1,rep(0,40),1,0,1,1,rep(0,231-211)), # room 209 - (Hallway)
                                       c(rep(0,44),1,rep(0,121),1, rep(0,41),1,0,0,1,rep(0,231-212)), # room 210 - (Hallway)
                                       c(rep(0,162),rep(1,4),rep(0,42),1,rep(0,7),1,1,rep(0,231-218)), # room 211 - (Hallway)
                                       c(rep(0,44),1,rep(0,122),rep(1,4),rep(0,38),1,rep(0,231-210)), # room 212 - (Hallway)
                                       c(rep(0,168),rep(1,4),rep(0,231-172)), # room 213 - (Hallway)
                                       c(rep(0,168),1,1,0,0,1,rep(0,41),1,rep(0,231-215)), # room 214 - (Hallway)
                                       c(rep(0,168),1, rep(0,6),1,1,1,rep(0,35),1,0,0,1,rep(0,231-217)), # room 215 - (Hallway)
                                       c(rep(0,182),rep(1,4),rep(0,30),1,rep(0,231-217)), # room 216 - (Hallway)
                                       c(rep(0,45),1,rep(0,136),1,rep(0,27),1,rep(0,3),1,1,0,0,1,rep(0,231-220),1), # room 217 - (Hallway)
                                       c(rep(0,195),1,1,rep(0,7),rep(1,3),rep(0,3),1,rep(0,8),1,rep(0,231-220)), # room 218 - (Hallway)
                                       c(rep(0,216),1,0,0,1,rep(0,231-220)), # room 219 - (Hallway)
                                       c(rep(0,92),1,rep(0,93),1,1,rep(0,5),1,1,0,0,0,1,rep(0,18),1,1,0,1,rep(0,231-221)), # room 220 - (Hallway)
                                       c(rep(0,46),1,rep(0,140),rep(1,8),rep(0,24),1,0,1,1,rep(0,231-223)), # room 221 - (Hallway)
                                       c(rep(0,177),1,0,1,1,1,rep(0,38),1,rep(0,231-221)), # room 222 - (Hallway)
                                       c(rep(0,177),1,1,rep(0,41),1,rep(0,231-221)), # room 223 - (Hallway)
                                       c(rep(0,43),1,rep(0,36),1,rep(0,143),1, rep(0,231-225)),# room 224 NW stairwell floor 1 to floor 2 (connects to 44 stair below, 81 - hallway on floor, 225 stair above)
                                       c(rep(0,140),1,rep(0,82),1,0,1, rep(0, 231-226)),# room 225 NW stairwell floor 2 to floor 3 (connects to 224 stair below, 141 - hallway on floor, 226 stair above)
                                       c(rep(0,207),1,rep(0, 16),1,rep(0,231-225)),# room 226 NW stairwell floor 3 (connects to 225 stair below, 208 - hallway on floor)
                                       c(rep(0,46),1,rep(0,44),1,rep(0,135),1, rep(0, 231-228)),# room 227 SE stairwell floor 1 to floor 2 (connects to 47 stair below, 92 - hallway on floor, 228 stair above)
                                       c(rep(0,153),1, rep(0,72),1,0,1,rep(0,231-229)),# room 228 SE stairwell floor 2 to floor 3 (connects to 227 stair below, 154 - hallway on floor, 229 stair above)
                                       c(rep(0,220),1,rep(0,6),1, rep(0,231-228)),# room 229 SE stairwell floor 3 (connects to 228 stair below, 221 - hallway on floor)
                                       c(rep(0,92),1,rep(0,56),1,0,0,1, rep(0,77),1),# room 230 Central stairwell floor 2 to floor 3 (connects to 93 stair below, 150 and 153 - hallway on floor, 231 stair above)
                                       c(rep(0,216),1, rep(0,12),1,0)# room 231 Central stairwell floor3 (connects to 230 stair below, 217 - hallway on floor)
)
,nrow = 231,ncol = 231)

# diag(University_adjacency_matrix) <- 1
# diag(University_adjacency_matrix) <- 1
# diag(Movie_adjacency_matrix) <- 1
diag(University_adjacency_matrix) <- 1

University_C <- c(rep(1,5),# rooms 1-5 storage / facilities
                  12, # room 6 research lab
                  rep(3,4), # rooms 7-10 Universitys
                  10, # room 11 - building services / equipment
                  1, # room 12 - storage
                  rep(4,4), # rooms 13-16 research labs
                  rep(1,5), # rooms 17-21 research lab storage
                  1, # room 22 storage
                  2, # room 23 lab storage
                  1, # room 24 storage
                  1, # room 25 storage - facilities
                  2, # room 26 facilities
                  2, # room 27 facilities
                  rep(4,2), # rooms 28 and 29 - bathrooms
                  rep(1,2), # rooms 30 and 31 - bathroom storage
                  10, # room 32 large unused space - wharehouse?
                  2, # room 33 facilities
                  10, # room 34 - large facilities
                  51, # rooms 35 hallway
                  27,# room 36 hallway
                  15, # room 37 - small hallway outside elevator
                  12, # rooms 38-42 hallways
                  37,# room 39
                  17,# room 40
                  29,# room 41
                  49,# room 42
                  63, # room 43 - small hallway by stairs
                  51, # room 44 stair
                  8, # room 45 elevator
                  8, # room 46 elevator
                  63, # room 47 stair
                  1, # room 48 storage
                  4, # room 49 Teaching lab small room
                  1, # room 50 connecting room to Universitys/ small common room
                  2, # room 51 storage - teaching lab
                  80, # room 52 Entryway
                  2, # room 53 Building services (elevator?)
                  rep(1,7), # rooms 54-60 Universitys
                  30, # room 61 - small teaching lab
                  30, # room 62 large teaching lab
                  4, # room 63 small teaching lab
                  30, # room 64 large teaching lab
                  30, # room 65 medium teaching lab
                  2, # room 66 storage
                  4, # room 67 storage
                  50, # room 68
                  18, # room 69
                  rep(1,3), # rooms 70-72 storage/ building services
                  rep(4,2), # rooms 73 and 74 - bathrooms
                  1, # room 75 storage
                  rep(1,4), # rooms 76-79 small classrooms -- update -- i think they are Universitys
                  225, # room 80 large lecture hall
                  58,# room 81 - hallway
                  70,# room 82 - hallway
                  7,# room 83 - hallway
                  115,# room 84 - hallway
                  81, # room 85 smaller hallway to teaching labs
                  171,# room 86
                  131,# room 87
                  225,# room 88
                  8,# room 89
                  3, # room 90 small hallway to storage rooms
                  226, # room 91 hallway with common area
                  115, # room 92 hallway
                  176, # room 93 - stair way
                  1, # room 94 storage
                  1, # room 95 University
                  rep(1,9), # rooms 96-104 Universitys
                  rep(30,2), # rooms 105 and 106 small classroom
                  1, # room 107 small research room
                  18, # room 108 research lab
                  44, # room 109 research lab / desks
                  1,# room 110
                  1,# room 111
                  1,# room 112
                  4,# room 113
                  4,# room 114
                  2,# room 115
                  rep(1,2), # rooms 116 and 117 - small storage
                  rep(1,3), # rooms 118-120 facilities
                  16, # rooms 121 large research lab
                  8, # room 122
                  10,# room 123
                  1, # room 124
                  5, # room 125
                  rep(1,7), # rooms 126-132 Universitys
                  rep(4,2), # rooms 133 and 134 bathrooms
                  10, # room 135 small common area
                  rep(1,3), # rooms 136-138 small Universitys
                  40, # room 139 large conference room
                  1, # room 140 facilities
                  109, # rooms 141 hallway
                  107, # room 142 hallway
                  102, # room 143 hallway
                  4, # room 144 hallway
                  42,# room 145 hallway
                  10,# room 146 hallway
                  10,# room 147 hallway
                  12,# room 148 hallway
                  3,# room 149 hallway
                  36,# room 150 hallway
                  28,# room 151 hallway
                  38,# room 152 hallway
                  40, # room 153 hallway with common area
                  43, # room 154
                  24, # room 155
                  1, # room 156 facilities
                  rep(1,10), # room 157-166 Universitys
                  30, # room 167 large conference room
                  1, # room 168 research lab storage
                  18, # room 169 large research lab
                  37, # room 170 research desk/lab space
                  rep(1,6 ), # room 171 - 176 research storage
                  2, # room 177 large storage
                  16, # room 178 large research lab
                  rep(10,2), # room 179 and 180 classroom
                  rep(1,6), # rooms 181 - 186 storage rooms
                  rep(1,7), # rooms 187 - 193 Universitys
                  rep(4, 2), # rooms 194 and 195 bathrooms
                  1, # room 196 University
                  5, # room 197 admin open space
                  1, # room 198 University
                  5, # room 199 admin open space
                  rep(1,7), # room 200 - 206 University space
                  1, # room 207 storage
                  32, # room 208 hallway
                  60, # room 209
                  55, # room 210 small hallway
                  64, # room 211 hallway
                  25, # room 212 hallway
                  7, # room 213 hallway
                  6, # room 214 hallway
                  8, # room 215 hallway
                  3, # room 216 hallway
                  86,# room 217 hallway
                  4, # room 218 hallway
                  17, # room 219 hallway
                  13, # room 220 hallway
                  7, # room 221 hallway
                  18, # room 222 hallway
                  16, # room 223 hallway
                  58,# room 224 stairwell
                  109,# room 225 stairwell
                  32,# room 226 stairwell
                  115,# room 227 stairwell
                  43,# room 228 stairwell
                  7,# room 229 stairwell
                  106,# room 230 stairwell
                  86# room 231 stairwell
) 



# #Now that we have building defined by the adjacency matrix, we need to specify the conditions in the building
# #{r Building paramaters}
# 
# Max_Building_Capacity_small_bld <- sum(small_bld_3_rooms_C) 
Max_Building_Capacity_University <- sum(University_C) 

Prop_full <- data.frame(ten = 0.1,twenty = 0.2, thirty = 0.3, forty = 0.4, fifty= 0.5, sixty = 0.6, seventy = 0.7, eighty = 0.8, ninety = 0.9, hundred = 1.0) # how full do we want our building capacity to be

#ten percent capacity
Adj_Max_Building_Capacity_University_ten <- round(Prop_full$ten[1]*Max_Building_Capacity_University,0) #Adjusted capacity - number of individuals that will be in the building such that building is at 'Prop_full' capacity


delt_University_ten<- Adj_Max_Building_Capacity_University_ten/community_pop # proportionality constant ( what proportion of individuals from the community are in the building of interest)

max_I <-Community_output %>% filter(I == max(I))

beg_day <- 25 # estimated inflection point 
mid_day <- max_I$time
end_day <- 70 # lower than peak but still much greater than the beginning

University_setup_ALL <- expand.grid(Occupancy = c(0.25,0.5, 0.75), Community_time = c(beg_day,mid_day), Max_bld_cap = sum(University_C))

University_setup_ALL <- University_setup_ALL %>% mutate(Adj_cap = round(Occupancy*Max_bld_cap,0), delt = Adj_cap/community_pop)
University_setup_ALL <- University_setup_ALL %>% mutate(Name = c("University_beg_out_low_occ","University_beg_out_med_occ","University_beg_out_high_occ",
                                                         "University_mid_out_low_occ","University_mid_out_med_occ","University_mid_out_high_occ"))
University_init_conds <- list(list())
for(i in 1:nrow(University_setup_ALL)){  
  University_init_conds_full <- Bld_setup_func_v2(
    Community_output = Community_output,
    day = University_setup_ALL$Community_time[i],
    delt = University_setup_ALL$delt[i], 
    N_rooms = length(University_C), 
    C_x = University_C, 
    N_total = University_setup_ALL$Adj_cap[i]
  ) 
  
  # Assign to the list using the name from University_setup_ALL$Name
  University_init_conds[[University_setup_ALL$Name[i]]] <- list(
    N_x = University_init_conds_full$N_x,
    P = University_init_conds_full$P,
    Ib_prop = University_init_conds_full$Ib_prop
  )
}

parms <-data.frame(s=2000,a=396, d=1.81,bet_bar = 25569.9504, bet_hat =67320)

# Initialize large dataframe object to append to. Soing this instead of reading in the lage file every time. 
#But I will still write_out/append to the file so I don't lose data
equil_t_mov <- Create_T_Matrix(adjacency_matrix_to_use = University_adjacency_matrix, N_rooms = length(University_C))
equil_theta_mov <-Create_T_Matrix(adjacency_matrix_to_use = University_adjacency_matrix, N_rooms = length(University_C))
equil_adj_cap <- University_setup_ALL$Adj_cap[1]
equil_Ib_prop <- University_init_conds[["University_beg_out_low_occ"]]$Ib_prop[1]
equil_Init_conds <- c(N_x = University_init_conds[["University_beg_out_low_occ"]]$N_x,P= University_init_conds[["University_beg_out_low_occ"]]$P)


Maxtime <- 24*50
test_times <- seq(from = 0, to = Maxtime, by = 1)
N_sims <- 100
Equil_University_setup_ALL <- University_setup_ALL %>% mutate(Equilib_time = 0)
equilib_time_data <- data.frame(iteration = seq(1:N_sims),Parm_set = NA, equilib_time = 0, check_steady = NA, check_persist = NA)

tolerance <- 1e-6
window_size <- 10 # Size of the moving window

Equilibrium_sim_func <- function(X){
  equil_t_mov <- Create_T_Matrix(adjacency_matrix_to_use = University_adjacency_matrix, N_rooms = length(University_C))
  equil_theta_mov <-Create_T_Matrix(adjacency_matrix_to_use = University_adjacency_matrix, N_rooms = length(University_C))
  #T_mov_file_name <- paste("/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Bifurcation_V2/",data_set_name,"_T_mov_matrix_",X,".text",sep = "")
  
  T_mov_file_name <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/University/T_mov_files/",data_set_name,"_T_mov_matrix_",X,".text",sep = "")
  Theta_mov_file_name <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/University/Theta_mov_files/",data_set_name,"_Theta_mov_matrix_",X,".text",sep = "")
  sim_file_name <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/University/Indv_files/",data_set_name,"_Indv_out",X,".text",sep = "")
  #test <-read.table(T_mov_file_name)
  #  Theta_mov_file_name <- paste("/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Bifurcation_V2/",data_set_name,"_Theta_mov_matrix_",X,".text",sep = "")
  
  write.table(equil_t_mov,file =T_mov_file_name, sep = " ")
  write.table(equil_theta_mov,file =Theta_mov_file_name, sep = " ")
  
  equilib_out <- data.frame(lsoda(y = equil_Init_conds, func = Particle_model_v3,times = test_times,
                                  parms = parms,
                                  adjacency_matrix_to_use=University_adjacency_matrix,
                                  theta_mov = equil_theta_mov,
                                  T_mov = equil_t_mov, 
                                  C_x= University_C,
                                  N_b = equil_Adj_cap,
                                  N_rooms = length(University_C),
                                  Ib_prop = equil_Ib_prop))
  
  
  check_steady <- NA
  check_perists <- NA
  sim <- X
  param_set <- basename(data_set_name)
  state_vars <- setdiff(names(equilib_out), "time")
  
  # Compute absolute changes for all state variables
  changes <- abs(diff(as.matrix(equilib_out[, state_vars])))
  
  # Sliding window approach to check for steady-state across all variables
  steady_state <- apply(changes, 2, function(var_changes) {
    sapply(seq_len(nrow(changes) - window_size + 1), function(i) {
      all(var_changes[i:(i + window_size - 1)] < tolerance)
    })
  })
  
  # Find the first time step where all state variables reach steady-state
  steady_time_index <- which(rowSums(steady_state) == length(state_vars))[1]
  
  if (!is.na(steady_time_index)) {
    steady_time <- equilib_out[steady_time_index, "time"]
    #message("Steady-state reached at time: ", steady_time)
    check_steady <- "Good"
  } else {
    # message("System did not reach steady-state within the simulation time.")
    check_steady <- "steady-state not reached"
  }
  
  # Ensure steady-state persists after steady_time
  check_perists
  if (!is.na(steady_time_index)) {
    persistent <- all(changes[seq(steady_time_index, nrow(changes)), ] < tolerance)
    if (persistent) {
      #message("Steady-state persists after the initial steady-state point.")
      check_perists <- "S.S. persists"
    } else {
      #message("Steady-state does not persist after it was initially reached.")
      check_perists <-"S.S. does NOT persists"
    }
  }else{
    check_perists <- "No S.S"
  }
  
  small_out <- equilib_out %>% mutate(sim = sim, param_set = param_set, check_steady = check_steady, check_perists = check_perists)
  
  write.table(small_out,file =sim_file_name, sep = " ",col.names = TRUE ,row.names = TRUE)
  
  return(sim_file_name)
}




for (i in 1:nrow(University_setup_ALL)) {  
  #print(paste("iteration ", i, "of for loop"))
  # Loop through the different parameter sets
  #Large_out_list <- list()
  equil_Init_conds <- c(N_x = University_init_conds[[University_setup_ALL$Name[i]]]$N_x,P= University_init_conds[[University_setup_ALL$Name[i]]]$P)
  #print(equil_Init_conds)
  Init_cnd_df <- as.data.frame(t(equil_Init_conds))
  equil_adj_cap <- c(University_setup_ALL$Adj_cap[i])
  #print(equil_adj_cap)
  equil_Ib_prop <- c(University_init_conds[[University_setup_ALL$Name[i]]]$Ib_prop[1])
  #print(equil_Ib_prop)
  #file_directory <- "/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/University_data/"
  #file_directory <- "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/University_data_smaller/"
  #file_name <- paste("/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/University_data_smaller/Test_",University_setup_ALL$Name[i],".text",sep = "")
  data_set_name <- University_setup_ALL$Name[i]
  #file_name <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/University/Full_output",University_setup_ALL$Name[i],".text",sep = "")
  #write.table(as.data.frame(c(time = 0, Init_cnd_df, sim = NA, param_set = NA, check_steady = NA, check_perists = NA)), 
  #           file = file_name, row.names = FALSE, col.names = TRUE)
  
  #test <-read.table(file_name, header = TRUE)
  #Run several iterations of the ode, store the times that it reaches equilibrium
  sim_files <- mclapply(FUN =Equilibrium_sim_func, X = 1:N_sims, mc.cores = detectCores())
  #write it out so we save the data in case it breaks
  all_data <- do.call(rbind, lapply(sim_files, read.table, header = TRUE))
  
  # Write final combined data
  final_output_file <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Bifurcation_V2/University/Full_output/", 
                             data_set_name, "_Final_Output.text", sep = "")
  write.table(all_data, file = final_output_file, sep = " ", row.names = TRUE, col.names = TRUE)
  
  
}
#test <- read.table(file =final_output_file, header = TRUE)
#print(test)
# if (!all(names(small_out) == column_names)) {
#   stop("Column names mismatch! Check your `small_out` structure.")
# }
#file_name2 <- paste("/home/cschrein/GitHub/CLS_2024_Particle-risk-model/Cluster_sims/Full_Equilib_University_",sep = "")
#write.table(Equil_University_setup_ALL,file =file_name2, sep = " ")
#test <-read.table(file_name, header = TRUE)

