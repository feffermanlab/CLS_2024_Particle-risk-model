library(tidyverse)
library(ggplot2)
library(igraph)
library(ggraph)
library(ggpubr)

#### Read in the 2000 church sims
file_directory <- "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Variance_data"


file_list_Church_var <- list.files(
  path = file_directory,
  pattern = "Church_output_var_[0-9]+\\.text",
  full.names = TRUE
)

# Read all files into a list of data frames
data_list <- lapply(file_list_Church_var, function(file) {
  read.table(file, header = TRUE, sep = " ")  # Adjust `sep` and `header` as needed
})

test <- bind_rows(setNames(data_list, basename(file_list_Church_var)), .id = "sim")

All_Church_data <- test%>% pivot_longer(cols = -c(time, sim),
                                        names_to = c("State", "Room"),
                                        names_pattern = "(P|N_x)(\\d+)",
                                        values_to = "Number")
All_Church_data_filtered_time <- All_Church_data %>% filter(time == max(time))

All_Church_data_wrangled <- All_Church_data_filtered_time %>% pivot_wider(names_from = c(State),values_from = c(Number)) %>% 
  group_by(time, Room)

write.table(All_Church_data_wrangled, file = "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Church_2000_sims.text",col.names = T)

test <- read.table(file ="/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Church_2000_sims.text" )
#### ^^At this point the columns of the data are: sim, time, Room, N_x, and P
# Now I'm going to group by sim and sum the number of particles in the whole building for each sim

All_Church_data_wrangled %>% ungroup()%>%
  group_by(sim,time) %>% 
  summarise(Total_P = sum(P)) %>% 
  ggplot(aes(y = Total_P,x= time))+geom_boxplot()


save <- All_Church_data_wrangled %>% ungroup() %>% 
  summarise(avg_Nx = mean(N_x),
            var_Nx = var(N_x),
            cum_mean = cumsum(N_x)/seq_along(N_x),
            std_error = sd(N_x)/sqrt(seq_along(N_x)),
            lower_ci = cum_mean - 1.96 * std_error,
            upper_ci = cum_mean + 1.96 * std_error,
            diffs = c(0,abs(diff(cum_mean))),
            conf_width = upper_ci - lower_ci,
            iteration = seq_along(N_x),
            .by = Room)

save %>% filter(iteration== max(iteration)) %>% ggplot( aes(x=Room, y = conf_width))+geom_point()
save  %>% ggplot( aes(x=iteration, y = conf_width, color = Room))+geom_point()

#### Read in the 2000 Office sims
file_directory <- "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Office_data/"


file_list_Office_var <- list.files(
  path = file_directory,
  pattern = "Office_output_var_[0-9]+\\.text",
  full.names = TRUE
)

# Read all files into a list of data frames
data_list <- lapply(file_list_Office_var, function(file) {
  read.table(file, header = TRUE, sep = " ")  # Adjust `sep` and `header` as needed
})

test <- bind_rows(setNames(data_list, basename(file_list_Office_var)), .id = "sim")

All_Office_data <- test%>% pivot_longer(cols = -c(time, sim),
                                        names_to = c("State", "Room"),
                                        names_pattern = "(P|N_x)(\\d+)",
                                        values_to = "Number")
All_Office_data_filtered_time <- All_Office_data %>% filter(time == max(time))

All_Office_data_wrangled <- All_Office_data_filtered_time %>% pivot_wider(names_from = c(State),values_from = c(Number)) %>% 
  group_by(time, Room)

write.table(All_Office_data_wrangled, file = "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Office_1101_sims.text",col.names = T)
Office_1000_sims <- read.table(file = "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Office_1101_sims.text")
#### ^^At this point the columns of the data are: sim, time, Room, N_x, and P
# Now I'm going to group by sim and sum the number of particles in the whole building for each sim

All_Office_data_wrangled %>% ungroup()%>%
  group_by(sim,time) %>% 
  summarise(Total_P = sum(P)) %>% 
  ggplot(aes(y = Total_P,x= time))+geom_boxplot()


#### Read in the 2000 movie sims 

file_directory <- "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Movie data/Movie_data/"


file_list_Movie_var <- list.files(
  path = file_directory,
  pattern = "Movie_output_var_[0-9]+\\.text",
  full.names = TRUE
)

# Read all files into a list of data frames
data_list <- lapply(file_list_Movie_var, function(file) {
  read.table(file, header = TRUE, sep = " ")  # Adjust `sep` and `header` as needed
})

test <- bind_rows(setNames(data_list, basename(file_list_Movie_var)), .id = "sim")


All_Movie_data_filtered_time <- test %>% filter(time == max(time))

All_Movie_data <- All_Movie_data_filtered_time%>% pivot_longer(cols = -c(time, sim),
                                        names_to = c("State", "Room"),
                                        names_pattern = "(P|N_x)(\\d+)",
                                        values_to = "Number")

All_Movie_data_wrangled <- All_Movie_data %>% pivot_wider(names_from = c(State),values_from = c(Number)) %>% 
  group_by(time, Room)

#### ^^At this point the columns of the data are: sim, time, Room, N_x, and P
# Now I'm going to group by sim and sum the number of particles in the whole building for each sim

All_Movie_data_wrangled %>% ungroup()%>%
  group_by(sim,time) %>% 
  summarise(Total_P = sum(P)) %>% 
  ggplot(aes(y = Total_P,x= time))+geom_boxplot()

write.table(All_Movie_data_wrangled, file = "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Movie_1001_sims.text",col.names = T)
Movie_1000_sims <- read.table(file = "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Movie_1001_sims.text")

