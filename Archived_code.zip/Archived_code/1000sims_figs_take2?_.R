library(tidyverse)
library(ggplot2)
library(igraph)
library(ggraph)
library(ggpubr)


Church_2000_sims <- read.table(file ="/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Church_2000_sims.text" )
test <- Church_2000_sims %>% ungroup() %>% group_by(sim) %>% slice(1:10)

selected_sims <- Church_2000_sims %>%
  distinct(sim) %>%
  slice_head(n = 1000) %>%
  pull(sim)

# Filter the dataset to keep only the selected simulations
Church_filtered_df <- Church_2000_sims %>%
  filter(sim %in% selected_sims)

Church_filtered_df %>% ungroup()%>%
  group_by(sim,time) %>% 
  summarise(Total_P = sum(P)) %>% 
  ggplot(aes(y = Total_P,x= time))+geom_boxplot()

#group by Room because we are finding the averages across sims and their variance but we need to keep the rooms together
save <- Church_filtered_df %>% group_by(Room)%>% 
  summarise(avg_Nx = mean(N_x),
            var_Nx = var(N_x),
            cum_mean = cumsum(N_x)/seq_along(N_x),
            std_error = sd(N_x)/sqrt(seq_along(N_x)),
            lower_ci = cum_mean - 1.96 * std_error,
            upper_ci = cum_mean + 1.96 * std_error,
            diffs = c(0,abs(diff(cum_mean))),
            conf_width = upper_ci - lower_ci,
            iteration = seq_along(N_x)
            )
save %>% filter(iteration== max(iteration)) %>% ggplot( aes(x=Room, y = conf_width))+geom_point()
save  %>% ggplot( aes(x=iteration, y = conf_width, color = Room))+geom_point()


Office_1000_sims <- read.table(file = "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Office_1101_sims.text")
#### ^^At this point the columns of the data are: sim, time, Room, N_x, and P
# Now I'm going to group by sim and sum the number of particles in the whole building for each sim


Office_selected_sims <- Office_1000_sims %>%
  distinct(sim) %>%
  slice_head(n = 1000) %>%
  pull(sim)

# Filter the dataset to keep only the selected simulations
Office_filtered_df <- Office_1000_sims %>%
  filter(sim %in% Office_selected_sims)

Office_filtered_df %>% ungroup()%>%
  group_by(sim,time) %>% 
  summarise(Total_P = sum(P)) %>% 
  ggplot(aes(y = Total_P,x= time))+geom_boxplot()



Movie_1000_sims <- read.table(file = "/Users/courtney/GitHub/CLS_2024_Particle-risk-model/Cluster_code/Movie_1001_sims.text")


Movie_selected_sims <- Movie_1000_sims %>%
  distinct(sim) %>%
  slice_head(n = 1000) %>%
  pull(sim)

# Filter the dataset to keep only the selected simulations
Movie_filtered_df <- Movie_1000_sims %>%
  filter(sim %in% Movie_selected_sims)


Movie_filtered_df %>% ungroup()%>%
  group_by(sim,time) %>% 
  summarise(Total_P = sum(P)) %>% 
  ggplot(aes(y = Total_P,x= time))+geom_boxplot()



temp <-bind_rows(Church_filtered_df,Office_filtered_df,Movie_filtered_df, .id = "Building")

temp %>% ungroup()%>%
  group_by(Building,sim,time) %>% 
  summarise(Total_P = sum(P)/sum(N_x)) %>% 
  ggplot(aes(y = Total_P,x= Building, color = Building))+geom_boxplot()+
  scale_color_manual(name = "Building",values =c("blue4", "red4", "green4"),
                     labels = c("Church","Office", "Movie"))







